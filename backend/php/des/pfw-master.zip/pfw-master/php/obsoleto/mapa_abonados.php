<?php
	
	/* 
		Dependecias: 
			config.h.
		
		Descripcion: 
			Clase para manejo de Mysql.
	*/

	require_once("config.php");

	/*
	$bd = new MapaAbonados(DB_MAPA_ABONADOS);


	$nombreArchivoCsv = "abonados.csv";
	$nombreTabla = TABLA_ABONADOS_DB_MAPA_ABONADOS;
	$registros = $bd->registros;


	$bd->csv_a_mysql($nombreArchivoCsv, $nombreTabla, $registros);
	*/


	echo "<br />";
	echo "<br />";
	echo "<br />";
	echo "<br />";
	echo "FIN";
?>